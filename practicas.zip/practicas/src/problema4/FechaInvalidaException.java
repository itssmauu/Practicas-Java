package problema4;

public class FechaInvalidaException extends Exception{
    public FechaInvalidaException(String mensaje){
        super(mensaje);
    }
}
